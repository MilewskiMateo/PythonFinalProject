from .FeetComponent import FeetComponent

__all__ = [
    "FeetComponent"
]