from .PeopleComponent import PeopleComponent

__all__ = [
    "PeopleComponent"
]